
const isValid = function (value) {
    if (typeof value === 'undefined' || value == null) return false;
    return true;
}

const isNotEmpty = function (value) {
    if (value.trim().length != 0) return true;
    return false;
}

const isWrong = function (value) {
    if (value.match(/^[A-Za-z]+$/)) return true;
    return false;
}

const emaiValid=function(value){
    if(value.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) )return true 
    return false
}

module.exports = { isValid, isNotEmpty, isWrong,emaiValid };

// let a= "akhielsh"
// if(!a.match(/^[A-Za-z]+$/)){
//     return console.log(false)
// }else{
// return console.log(true)
// }
